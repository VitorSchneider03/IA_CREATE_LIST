package com.example.list_ia

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
